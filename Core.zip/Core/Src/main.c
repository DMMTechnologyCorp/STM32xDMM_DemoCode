/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include <ctype.h>
#include <stdio.h>
#include <strings.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <unistd.h> // For sleep() function
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define Go_Absolute_Pos         0x01
#define Go_Relative_Pos         0x03
#define Is_AbsPos32             0x1b
#define General_Read            0x0e
#define Is_TrqCurrent           0x1E
#define Read_MainGain           0x18
#define Set_MainGain            0x10
#define Set_SpeedGain           0x11
#define Set_IntGain             0x12
#define Set_HighSpeed           0x14
#define Set_HighAccel           0x15
#define Set_Pos_OnRange         0x16
#define Is_MainGain             0x10
#define Is_SpeedGain            0x11
#define Is_IntGain              0x12
#define Is_TrqCons              0x13
#define Is_HighSpeed            0x14
#define Is_HighAccel            0x15
#define Is_Driver_ID            0x16
#define Is_Pos_OnRange          0x17
#define Is_Status               0x19
#define Is_Config               0x1a
#define Is_MotorSpeed			0x1d
#define Is_DriveReset			0x1c
#define Is_DriveEnable			0x20
#define Is_DriveDisable			0x21
#define UART2_BAUD				115200 //Set Baud Rate for USB Communication (To Tablet or Computer)
#define UART3_BAUD				38400 //Set Baud Rate for DYN Drive Communication (Nominally 38400)

//USE PIN PC4 ON CN10 FOR TX

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
TIM_HandleTypeDef htim3;

UART_HandleTypeDef huart2;
UART_HandleTypeDef huart3;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM3_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_USART3_UART_Init(void);
/* USER CODE BEGIN PFP */
void clockwiseMotion();
void counterClockwiseMotion();
void speedControl(char*);
void absoluteMove(char*);
void absMoveSetup();
int goHome();

//Reading & Display Function Prototypes
void sendString();
void classifyReadString(long, char, char*);
char* ltoa(long, char*, int);

//Timer Functions
void timeDelay(int);

//Drive Function Prototypes
void Drive_Reset_RS232();
void Drive_Enable_RS232();
void Drive_Disable_RS232();
void move_rel32(char,long);
void ReadMotorTorqueCurrent(char);
void ReadMotorPosition32(char);
void ReadMotorSpeed32(char);
void move_abs32(char,long);
void Turn_const_speed(char,long);
void ReadPackage();
void Get_Function();
int32_t Cal_SignValue(unsigned char*);
long Cal_Value(unsigned char*);
void Send_Package(char,long);
void Make_CRC_Send(unsigned char, unsigned char*);

//Menu Functions
void speedMenu();
void positionMenu();
char updateMotorData(char,int,long);

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
char InputBuffer[256];                          //Input buffer from RS232,
char OutputBuffer[256]; //Output buffer to RS232,
char outputString[20];
unsigned char InBfTopPointer, InBfBtmPointer;   //input buffer pointers
unsigned char OutBfTopPointer, OutBfBtmPointer; //output buffer pointers
unsigned char Read_Package_Buffer[8], Read_Num, Read_Package_Length, Global_Func;
unsigned char MotorPosition32Ready_Flag, MotorTorqueCurrentReady_Flag, MainGainRead_Flag, MotorSpeed32Ready_Flag;
unsigned char Driver_MainGain, Driver_SpeedGain, Driver_IntGain, Driver_TrqCons, Driver_HighSpeed, Driver_HighAccel,Driver_ReadID,Driver_Status,Driver_Config,Driver_OnRange;
long Motor_Pos32, MotorTorqueCurrent, Motor_Speed32;
/* USER CODE BEGIN 0 */
int speed = 0;
int position = 0;
int sendSpeed;
char speedParse;
int motorPower;
char motorDirection = 0; //motorDirection = 1 (CW), motorDirection = 2 (CCW), 0 on startup
char delayDone = 0;

char posMenu = 0;
char trqMenu = 0;

/* USER CODE END 0 */

void HAL_TIM_OC_DelayElapsedCallback(TIM_HandleTypeDef* htim){

	if(htim->Channel == HAL_TIM_ACTIVE_CHANNEL_1){
		HAL_TIM_OC_Stop(&htim3, TIM_CHANNEL_1);
		__HAL_TIM_SET_COUNTER(&htim3,0);
		delayDone = 1;
		//HAL_GPIO_TogglePin(GPIOC,Outside_Light_Pin);
	}

}


/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM3_Init();
  MX_USART2_UART_Init();
  MX_USART3_UART_Init();
  /* USER CODE BEGIN 2 */
  motorPower = 0;

  char rx_data; // Variable to store received character
  int rx_index = 0; // Index to keep track of received characters
  char sendMsg[256];
  char commandType;
  char commandValue;
  HAL_StatusTypeDef status;
  char menu[] = "\x1b[1m\r\nDMM STM32 Demo Menu:\r\n\x1b[0m\r\n \x1b[1;36m[1]\tEnable/Disable Drive\r\n\x1b[0m \x1b[1;36m[2]\tSpeed Control\r\n\x1b[0m \x1b[1;36m[3]\tPosition Control\r\n\x1b[0m \x1b[1;36m[4]\tHome Motor\r\n\x1b[0m \x1b[1;36m[5]\tDrive Reset\r\n\x1b[0m\r\nSelect an option: ";

  Turn_const_speed(1,0);
  /* USER CODE END 2 */

  HAL_UART_Transmit(&huart2, (uint8_t *)"\x1b[0;0H\x1b[2J", strlen("\x1b[0;0H\x1b[2J"), HAL_MAX_DELAY);
  timeDelay(250);

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */
	  HAL_UART_Transmit(&huart2, (uint8_t *)menu, strlen(menu), HAL_MAX_DELAY); // Transmit menu over UART

	  HAL_UART_Receive(&huart2, (uint8_t *)&rx_data, 1, HAL_MAX_DELAY); // Receive user input

	          // Handle user selection
	  switch (rx_data){
	  case '1':
		  HAL_UART_Transmit(&huart2, (uint8_t *)"\x1b[1mEnable/Disable Drive\r\n\x1b[0m", strlen("\x1b[1mEnable/Disable Drive\r\n\x1b[0m"), HAL_MAX_DELAY);
		  motorPower = !motorPower;
		  if(motorPower == 1){
			  Drive_Enable_RS232();
			  HAL_UART_Transmit(&huart2, (uint8_t *)"\r\n\x1b[1mDrive Enabled!\r\n\x1b[0m", strlen("\r\n\x1b[1mDrive Enabled!\r\n\x1b[0m"), HAL_MAX_DELAY);
		  //add enable code here
		  }

		  else if(motorPower == 0){
			  Drive_Disable_RS232();
			  HAL_UART_Transmit(&huart2, (uint8_t *)"\r\n\x1b[1mDrive Disabled!\r\n\x1b[0m", strlen("\r\n\x1b[1mDrive Disabled!\r\n\x1b[0m"), HAL_MAX_DELAY);
		  //add disable code here
		  }
		  break;
	  case '2':
		  HAL_UART_Transmit(&huart2, (uint8_t *)"\x1b[0;0H\x1b[2J", strlen("\x1b[0;0H\x1b[2J"), HAL_MAX_DELAY);
		  timeDelay(100);
		  speedMenu();
		  break;
	  case '3':
		  HAL_UART_Transmit(&huart2, (uint8_t *)"\x1b[0;0H\x1b[2J", strlen("\x1b[0;0H\x1b[2J"), HAL_MAX_DELAY);
		  timeDelay(100);
		  positionMenu();
	      break;
	  case '4':
		  HAL_UART_Transmit(&huart2, (uint8_t *)"\x1b[1mHome Motor\r\n\x1b[0m", strlen("\x1b[1mHome Motor\r\n\x1b[0m"), HAL_MAX_DELAY);
		  int done = goHome();
		  if(done == 5){
			  HAL_UART_Transmit(&huart2, (uint8_t *)"\r\n\x1b[1;31mHoming Failed! Ensure motor has been enabled!\r\n\x1b[0m", strlen("\r\n\x1b[1;31mHoming Failed! Ensure motor has been enabled!\r\n\x1b[0m"), HAL_MAX_DELAY);
			  break;
		  }
		  while(done != 1);
		  timeDelay(2500);
		  ReadMotorPosition32(1);
		  while(Motor_Pos32 !=0){
			  ReadMotorPosition32(1);
		  }
		  sprintf(sendMsg,"\r\nCurrent Position at: %ld\r\n\n\x1b[1mHoming Complete!\r\n\x1b[0m\r\nReturning to Main Menu...\r\n",Motor_Pos32);
		  HAL_UART_Transmit(&huart2, (uint8_t *)sendMsg, strlen(sendMsg), HAL_MAX_DELAY); // Transmit menu over UART
		  timeDelay(3000);
		  HAL_UART_Transmit(&huart2, (uint8_t *)"\x1b[0;0H\x1b[2J", strlen("\x1b[0;0H\x1b[2J"), HAL_MAX_DELAY);
	      break;
	  case '5':
		  HAL_UART_Transmit(&huart2, (uint8_t *)"\x1b[1mDrive Reset\r\n\x1b[0m", strlen("\x1b[1mDrive Reset\r\n\x1b[0m"), HAL_MAX_DELAY);
		  Drive_Reset_RS232();
		  //option to add a driver status check. Read status bits from drive and confirm its in an ok state
		  break;

	  default:
	              // Invalid selection
	      HAL_UART_Transmit(&huart2, (uint8_t *)"\x1b[1;31mInvalid selection!\r\n\x1b[0m", strlen("\x1b[1;31mInvalid selection!\r\n\x1b[0m"), HAL_MAX_DELAY);
	      break;
	  }
  }

  /* USER CODE END 3 */
}

void speedMenu(){

	char speedMenu[] = "\x1b[1m\r\nSpeed Control:\r\n\x1b[0m\r\n \x1b[1;36m[1]\tSet Direction\r\n\x1b[0m \x1b[1;36m[2]\tSet Speed\r\n\x1b[0m \x1b[1;36m[3]\tGO!\r\n\x1b[0m\r\nPress [X] at any point to exit speed control.\r\n\r\n";
	char rx_data; // Variable to store received character
	int rx_index = 0;
	char rx_buffer[30]; // Buffer to store received string
	char sendMsg [100];
	char spdMenu = 1;
	char isTyping = 0;
	char dirSelect = 0;
	int speedTemp = 0;

	while(spdMenu == 1){

		HAL_UART_Transmit(&huart2, (uint8_t *)speedMenu, strlen(speedMenu), HAL_MAX_DELAY); // Transmit menu over UART

		HAL_UART_Receive(&huart2, (uint8_t *)&rx_data, 1, HAL_MAX_DELAY); // Receive user input

		switch(rx_data){
		case '1':
			HAL_UART_Transmit(&huart2, (uint8_t *)"\r\nChoose the direction of rotation:\r\n\r\n [1]\tClockwise\r\n [2]\tCounter-Clockwise\r\n\r\n\r\n", strlen("\r\nChoose the direction of rotation:\r\n\r\n [1]\tClockwise\r\n[2]\tCounter-Clockwise\r\n\r\n\r\n"), HAL_MAX_DELAY);
			HAL_UART_Receive(&huart2, (uint8_t *)&rx_data, 1, HAL_MAX_DELAY); // Receive user input
			dirSelect = 1;

			while(dirSelect == 1){
				switch(rx_data){
				case '1':
					HAL_UART_Transmit(&huart2, (uint8_t *)"\x1b[1mClockwise\r\n\x1b[0m", strlen("\x1b[1mClockwise\r\n\x1b[0m"), HAL_MAX_DELAY);
					motorDirection = 1;
					dirSelect = 0;
					break;
				case '2':
					HAL_UART_Transmit(&huart2, (uint8_t *)"\x1b[1mCounter-Clockwise\r\n\x1b[0m", strlen("\x1b[1mCounter-Clockwise\r\n\x1b[0m"), HAL_MAX_DELAY);
					motorDirection = 2;
					dirSelect = 0;
					break;
				default:
					HAL_UART_Transmit(&huart2, (uint8_t *)"\x1b[1;31mInvalid selection!\r\n\x1b[0m", strlen("\x1b[1;31mInvalid selection!\r\n\x1b[0m"), HAL_MAX_DELAY);
					break;
				}
			}

			break;
		case '2':
			HAL_UART_Transmit(&huart2, (uint8_t *)"\r\nEnter Speed (RPM): ", strlen("\r\nEnter Speed (RPM): "), HAL_MAX_DELAY);
			isTyping = 1;
			rx_index = 0;

			while(isTyping == 1){

				if (HAL_UART_Receive(&huart2, (uint8_t *)&rx_data, 1, HAL_MAX_DELAY) == HAL_OK){


					if(rx_data == 'x' || rx_data =='X'){
						isTyping = 0;
						spdMenu = 0;
						HAL_UART_Transmit(&huart2, (uint8_t *)"\x1b[0;0H\x1b[2J", strlen("\x1b[0;0H\x1b[2J"), HAL_MAX_DELAY);
						timeDelay(250);
					}

					if(rx_data == '\r'){

						rx_buffer[rx_index] = '\0';
						rx_index = 0;
						speedTemp = atoi(rx_buffer);
						//insert software limits on speed here
						if(speedTemp < 0 || speedTemp > 3000){
							HAL_UART_Transmit(&huart2, (uint8_t *)"\r\n\r\n\x1b[1;31mInvalid input!\r\n\r\nSpeed must be between 0 and 3000 RPM!\n\n\r\x1b[0m", strlen("\r\n\r\n\x1b[1;31mInvalid input!\r\n\r\nSpeed must be between 0 and 3000 RPM!\n\n\r\x1b[0m"), HAL_MAX_DELAY);
							memset(rx_buffer,' ',30);
							timeDelay(250);
							HAL_UART_Transmit(&huart2, (uint8_t *)"Enter Speed (RPM): ", strlen("Enter Speed (RPM): "), HAL_MAX_DELAY);
						}
						else{
							isTyping = 0;
							speed = speedTemp;
							sprintf(sendMsg,"\r\n\n\x1b[1mMotor speed set to %d RPM\x1b[0m\r\n", speedTemp);
							HAL_UART_Transmit(&huart2, (uint8_t *)sendMsg, strlen(sendMsg), HAL_MAX_DELAY); // Transmit menu over UART
						}


					}
					else{

						rx_buffer[rx_index++] = rx_data;

		                if (rx_index >= 30){
		                    // Handle buffer overflow (e.g., by discarding excess characters)
		                    rx_index = 0; // Reset buffer index
		                }

		                HAL_UART_Transmit(&huart2, (uint8_t *)&rx_data, 1, HAL_MAX_DELAY); // Transmit menu over UART

					}

				}

			}
			break;
		case '3':
			if(motorDirection == 1){
				HAL_UART_Transmit(&huart2, (uint8_t *)"\x1b[0;0H\x1b[2J", strlen("\x1b[0;0H\x1b[2J"), HAL_MAX_DELAY);
				timeDelay(250);
				sprintf(sendMsg,"\x1b[1mMoving Clockwise at %d RPM\r\n\r\n[Space] - Change Direction\t[X] - Main Menu\t\t[B] - Previous Menu\x1b[0m\r\n\n", speedTemp);
				HAL_UART_Transmit(&huart2, (uint8_t *)sendMsg, strlen(sendMsg), HAL_MAX_DELAY); // Transmit menu over UART
				clockwiseMotion();
				char code = updateMotorData(2, speedTemp,0);
				if(code == 1){
					spdMenu = 0;
				}

				//scan for user inputs, format speed and position output
			}
			else if(motorDirection == 2){
				HAL_UART_Transmit(&huart2, (uint8_t *)"\x1b[0;0H\x1b[2J", strlen("\x1b[0;0H\x1b[2J"), HAL_MAX_DELAY);
				timeDelay(250);
				sprintf(sendMsg,"\x1b[1mMoving Counter-Clockwise at %d RPM\r\n\r\n[Space] - Change Direction\t[X] - Main Menu\t\t[B] - Previous Menu\x1b[0m\r\n\n", speedTemp);
				HAL_UART_Transmit(&huart2, (uint8_t *)sendMsg, strlen(sendMsg), HAL_MAX_DELAY); // Transmit menu over UART
				counterClockwiseMotion();
				char code = updateMotorData(2, speedTemp,0);
				if(code == 1){
					spdMenu = 0;
				}
				//scan for user inputs, format speed and position output
			}
			else{
				HAL_UART_Transmit(&huart2, (uint8_t *)"\x1b[1;31mMotor direction not set!\r\n\r\nSet motor direction prior to moving!\n\r\x1b[0m", strlen("\x1b[1;31mMotor direction not set!\r\n\r\nSet motor direction prior to moving!\n\r\x1b[0m"), HAL_MAX_DELAY);
			}
			break;
		case 'X':
			HAL_UART_Transmit(&huart2, (uint8_t *)"\x1b[0;0H\x1b[2J", strlen("\x1b[0;0H\x1b[2J"), HAL_MAX_DELAY);
			timeDelay(250);
			spdMenu = 0;
			break;
		case 'x':
			HAL_UART_Transmit(&huart2, (uint8_t *)"\x1b[0;0H\x1b[2J", strlen("\x1b[0;0H\x1b[2J"), HAL_MAX_DELAY);
			timeDelay(250);
			spdMenu = 0;
			break;
		default:
			HAL_UART_Transmit(&huart2, (uint8_t *)"\x1b[1;31mInvalid selection!\r\n\x1b[0m", strlen("\x1b[1;31mInvalid selection!\r\n\x1b[0m"), HAL_MAX_DELAY);
			break;
		}
	}

}

void positionMenu(){

	char positionMenu[] = "\x1b[1m\r\nPosition Control:\r\n\x1b[0m\r\n \x1b[1;36m[1]\tAbsolute Move (in pulses)\r\n\x1b[0m \x1b[1;36m[2]\tRelative Move (by revolution count)\r\n\x1b[0m\r\nPress [X] at any point to exit position control.\r\n\r\n";
	char rx_data; // Variable to store received character
	int rx_index = 0;
	char currentPos[256];
	char sendMsg [100];
	char posMenu = 1;
	char isTyping = 0;
	long posTemp = 0;
	int revCnt = 0;
	char rx_buffer[30]; // Buffer to store received string

	while(posMenu == 1){

		HAL_UART_Transmit(&huart2, (uint8_t *)positionMenu, strlen(positionMenu), HAL_MAX_DELAY); // Transmit menu over UART
		HAL_UART_Receive(&huart2, (uint8_t *)&rx_data, 1, HAL_MAX_DELAY); // Receive user input

		switch(rx_data){
		case '1':
			ReadMotorPosition32(1);
			timeDelay(25);
			sprintf(currentPos,"\x1b[1m\r\nCurrent Motor Position:\x1b[0m \x1b[1;36m %ld [Pulses]\x1b[0m\n\n",Motor_Pos32);
			HAL_UART_Transmit(&huart2, (uint8_t *)currentPos, strlen(currentPos), HAL_MAX_DELAY); // Transmit menu over UART
			HAL_UART_Transmit(&huart2, (uint8_t *)"\r\nEnter the Destination Position (Encoder Pulses): ", strlen("\r\nEnter the Destination Position (Encoder Pulses): "), HAL_MAX_DELAY);
			isTyping = 1;
			rx_index = 0;

			while(isTyping == 1){

				if (HAL_UART_Receive(&huart2, (uint8_t *)&rx_data, 1, HAL_MAX_DELAY) == HAL_OK){


					if(rx_data == 'x' || rx_data =='X'){
						isTyping = 0;
						posMenu = 0;
						HAL_UART_Transmit(&huart2, (uint8_t *)"\x1b[0;0H\x1b[2J", strlen("\x1b[0;0H\x1b[2J"), HAL_MAX_DELAY);
						timeDelay(250);
					}

					if(rx_data == '\r'){
						rx_buffer[rx_index] = '\0';
						rx_index = 0;
						posTemp = strtol(rx_buffer,NULL,10);
						//insert software limits on speed here
						if(posTemp > 134217727 || posTemp < -134217728){
							HAL_UART_Transmit(&huart2, (uint8_t *)"\r\n\r\n\x1b[1;31mInvalid input!\r\n\r\nPosition must be between -134217728 and 134217727 Pulses!\n\n\r\x1b[0m", strlen("\r\n\r\n\x1b[1;31mInvalid input!\r\n\r\nPosition must be between -134217728 and 134217727 Pulses!\n\n\r\x1b[0m"), HAL_MAX_DELAY);
							memset(rx_buffer,' ',30);
							timeDelay(250);
							HAL_UART_Transmit(&huart2, (uint8_t *)"Enter the Destination Position (Encoder Pulses): ", strlen("Enter the Destination Position (Encoder Pulses): "), HAL_MAX_DELAY);
						}
						else{
							isTyping = 0;
							position = posTemp;
							HAL_UART_Transmit(&huart2, (uint8_t *)"\x1b[0;0H\x1b[2J", strlen("\x1b[0;0H\x1b[2J"), HAL_MAX_DELAY);
							timeDelay(25);
							sprintf(sendMsg,"\r\x1b[1mTarget Position set to %ld Pulses\x1b[0m\r\n\nPress [SPACE] to perform an Absolute Move.\r\n\n[B] to return to position menu\n\n\r[X] to return to main menu\r\n\n", posTemp);
							HAL_UART_Transmit(&huart2, (uint8_t *)sendMsg, strlen(sendMsg), HAL_MAX_DELAY); // Transmit menu over UARTbbbbb
							char code = updateMotorData(3,0,posTemp);
							if(code == 1){
								posMenu = 0;
							}

						}
					}
					if(isTyping == 1){

						rx_buffer[rx_index++] = rx_data;

		                if (rx_index >= 30){
		                    // Handle buffer overflow (e.g., by discarding excess characters)
		                    rx_index = 0; // Reset buffer index
		                }
						HAL_UART_Transmit(&huart2, (uint8_t *)&rx_data, 1, HAL_MAX_DELAY); // Transmit menu over UART
					}
				}
			}
			break;
		case '2':
			HAL_UART_Transmit(&huart2, (uint8_t *)"\r\nEnter desired number of rotations (Whole Numbers ONLY): ", strlen("\r\nEnter desired number of rotations (Whole Numbers Only): "), HAL_MAX_DELAY);
			isTyping = 1;

			while(isTyping == 1){

				if (HAL_UART_Receive(&huart2, (uint8_t *)&rx_data, 1, HAL_MAX_DELAY) == HAL_OK){


					if(rx_data == 'x' || rx_data =='X'){
						isTyping = 0;
						posMenu = 0;
						HAL_UART_Transmit(&huart2, (uint8_t *)"\x1b[0;0H\x1b[2J", strlen("\x1b[0;0H\x1b[2J"), HAL_MAX_DELAY);
						timeDelay(250);
					}

					if(rx_data == '\r'){
						rx_buffer[rx_index] = '\0';
						rx_index = 0;
						revCnt = atoi(rx_buffer);
						isTyping = 0;
						HAL_UART_Transmit(&huart2, (uint8_t *)"\x1b[0;0H\x1b[2J", strlen("\x1b[0;0H\x1b[2J"), HAL_MAX_DELAY);
						timeDelay(25);
						sprintf(sendMsg,"\r\x1b[1mTarget number of Revolutions set to: %d\x1b[0m\r\n\nPress [SPACE] to perform a Relative Move.\r\n\n[B] to return to position menu\n\n\r[X] to return to main menu\r\n\n",revCnt);
						HAL_UART_Transmit(&huart2, (uint8_t *)sendMsg, strlen(sendMsg), HAL_MAX_DELAY); // Transmit menu over UART
						char code = updateMotorData(4,revCnt,0);
						if(code == 1){
							posMenu = 0;
						}

					}
					if(isTyping == 1){

						rx_buffer[rx_index++] = rx_data;

		                if (rx_index >= 30){
		                    // Handle buffer overflow (e.g., by discarding excess characters)
		                    rx_index = 0; // Reset buffer index
		                }
						HAL_UART_Transmit(&huart2, (uint8_t *)&rx_data, 1, HAL_MAX_DELAY); // Transmit menu over UART
					}
				}
			}
			break;
		case 'X':
			HAL_UART_Transmit(&huart2, (uint8_t *)"\x1b[0;0H\x1b[2J", strlen("\x1b[0;0H\x1b[2J"), HAL_MAX_DELAY);
			timeDelay(250);
			posMenu = 0;
			break;
		case 'x':
			HAL_UART_Transmit(&huart2, (uint8_t *)"\x1b[0;0H\x1b[2J", strlen("\x1b[0;0H\x1b[2J"), HAL_MAX_DELAY);
			timeDelay(250);
			posMenu = 0;
			break;
		default:
			HAL_UART_Transmit(&huart2, (uint8_t *)"\x1b[1;31mInvalid selection!\r\n\x1b[0m", strlen("\x1b[1;31mInvalid selection!\r\n\x1b[0m"), HAL_MAX_DELAY);
			break;
		}
	}

}

char updateMotorData(char controlMode, int RPM, long position){

	char reading = 1;
	char data[256];
	char sendMsg[100];
	char rx_data;
	char code = 0;

	HAL_NVIC_SetPriority(USART2_IRQn,0,0);
	HAL_NVIC_EnableIRQ(USART2_IRQn);

	while(reading == 1){

		ReadMotorPosition32(1);
		timeDelay(25);
		ReadMotorSpeed32(1);
		timeDelay(25);
		sprintf(data,"\x1b[G\x1b[2KPostion: %ld [Pulses]\t||\tSpeed: %ld [RPM]",Motor_Pos32, Motor_Speed32);

		HAL_UART_Transmit(&huart2, (uint8_t *)data, strlen(data), HAL_MAX_DELAY); // Transmit menu over UART


		if(__HAL_UART_GET_FLAG(&huart2, UART_FLAG_RXNE) != RESET){
			HAL_UART_Receive(&huart2, &rx_data, 1, HAL_MAX_DELAY);

			if(rx_data == 'x' || rx_data == 'X'){
				reading = 0;
				code = 1;
				HAL_UART_Transmit(&huart2, (uint8_t *)"\x1b[0;0H\x1b[2J", strlen("\x1b[0;0H\x1b[2J"), HAL_MAX_DELAY);
				Turn_const_speed(1,0);
			}
			else if(rx_data == 'b' || rx_data == 'B'){
				reading = 0;
				Turn_const_speed(1,0);
				HAL_UART_Transmit(&huart2, (uint8_t *)"\x1b[0;0H\x1b[2J", strlen("\x1b[0;0H\x1b[2J"), HAL_MAX_DELAY);
				timeDelay(250);
			}
			else if(rx_data == ' ' && controlMode == 2){
				if (motorDirection == 1){
					motorDirection = 2;
					HAL_UART_Transmit(&huart2, (uint8_t *)"\x1b[0;0H\x1b[2J", strlen("\x1b[0;0H\x1b[2J"), HAL_MAX_DELAY);
					timeDelay(250);
					sprintf(sendMsg,"\x1b[1mMoving Counter-Clockwise at %d RPM\r\n\r\n[Space] - Change Direction\t[X] - Main Menu\t\t[B] - Previous Menu\x1b[0m\r\n\n", RPM);
					counterClockwiseMotion();
					HAL_UART_Transmit(&huart2, (uint8_t *)sendMsg, strlen(sendMsg), HAL_MAX_DELAY); // Transmit menu over UART
				}
				else if(motorDirection == 2){
					motorDirection = 1;
					HAL_UART_Transmit(&huart2, (uint8_t *)"\x1b[0;0H\x1b[2J", strlen("\x1b[0;0H\x1b[2J"), HAL_MAX_DELAY);
					timeDelay(250);
					sprintf(sendMsg,"\x1b[1mMoving Clockwise at %d RPM\r\n\r\n[Space] - Change Direction\t[X] - Main Menu\t\t[B] - Previous Menu\x1b[0m\r\n\n", RPM);
					clockwiseMotion();
					HAL_UART_Transmit(&huart2, (uint8_t *)sendMsg, strlen(sendMsg), HAL_MAX_DELAY); // Transmit menu over UART
				}
			}
			else if(rx_data == ' ' && controlMode == 3){

				move_abs32(1,position);
			}
			else if(rx_data == ' ' && controlMode == 4){

				ReadMotorPosition32(1);
				long targetPos = 65536 * RPM;
				move_rel32(1,targetPos);

			}

		}
		//use the on board user input to exit OR configure uart interrupts - TODO

	}
	HAL_NVIC_DisableIRQ(USART2_IRQn);
	return code;
}
///////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////CONTROL FUNCTIONS (CAN CHANGE)////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////

/* Function Name: clockwiseMotion
 * Author: Aidan Drescher
 * Date: 2024-02-21
 * Purpose: Send a command packet to DMM drive to initiate clockwise motion of the shaft with user
 * defined speed
 * */
void clockwiseMotion(){
	if(motorPower == 0){
		return;
	}
	else if(motorPower == 1){
		sendSpeed = speed;
		Turn_const_speed(1,sendSpeed);
		motorDirection = 1;
	}
}

/* Function Name: counterClockwiseMotion
 * Author: Aidan Drescher
 * Date: 2024-02-21
 * Purpose: Send a command packet to DMM drive to initiate counter-clockwise motion of the shaft
 * with user defined speed
 * */
void counterClockwiseMotion(){
	if(motorPower == 0){
		return;
	}
	else if(motorPower == 1){
		sendSpeed = speed*-1;
		Turn_const_speed(1,sendSpeed);
		motorDirection = 2;
	}
}

/* Function Name: speedControl
 * Author: Aidan Drescher
 * Date: 2024-02-21
 * Purpose: Parse incoming speed commands to separate the command type and the real value. Change
 * the multiplier to adjust the scale of the speed
 * */
void speedControl(char* command){
  int index = 0;
  int i = 0;
  char speedVal[3] = {};
  for(i=0; command[i]!='\0'; i++){
	  if(isdigit(command[i])){
	      speedVal[index] = command[i];
	      index++;
	  }
  }
  speed = atoi(speedVal);
  speed = speed * 10; //change multiplier here to determine max speed (motor rated 3000RPM - set to 30)

  if(motorDirection == 1){
	  clockwiseMotion();
  }
  else if(motorDirection == 2){
	  counterClockwiseMotion();
  }
}

/* Function Name: absoluteMove
 * Author: Aidan Drescher
 * Date: 2024-02-21
 * Purpose: Parse incoming absolute move commands to separate the command type and the real value.
 * The function computes the move time based on # of revolutions and calls appropriate functions
 * to execute the move (move_rel32)
 * */
void absoluteMove(char* command){
	int index = 0;
	int i = 0;
	char revCount[3] = {};
	long int noRev = 0;
	int moveTime = 0;
	if(motorPower == 0){
		return;
	}
	else if(motorPower == 1){
		motorDirection = 0;
		Turn_const_speed(1,0);
		timeDelay(2000);
		//while timer is not done, wait (still run read data for position display)
		for(i=0; command[i]!='\0'; i++){
			if(isdigit(command[i])){
			    revCount[index] = command[i];
			    index++;
			}
		}
		noRev = atoi(revCount);
		moveTime = 550 * noRev;
		if(command[1] == '-'){
		    noRev = noRev * -65536;
			move_rel32(1,noRev);
			timeDelay(moveTime);
		}
		else{
			noRev = noRev * 65536;
			move_rel32(1,noRev);
			timeDelay(moveTime);
		}
	}
}

/* Function Name: absMoveSetup
 * Author: Aidan Drescher
 * Date: 2024-04-10
 * Purpose: Ensures positional accuracy before relative moves
 * */
void absMoveSetup(){

	for(int i=0; i<45; i++){
		//sendString();
		timeDelay(75);
	}
}

/* Function Name: goHome
 * Author: Aidan Drescher
 * Date: 2024-03-19
 * Purpose: Sends the motor back to 0 pulses on the encoder
 * */
int goHome(){

  if(motorPower == 0){
    return 5;
  }
  else if(motorPower == 1){

    motorDirection = 0;
    Turn_const_speed(1,0);
    ReadMotorPosition32(1);

    if(Motor_Pos32 > 400000){
      while(Motor_Pos32 > 400000){
        //sendString();
    	ReadMotorPosition32(1);
        Turn_const_speed(1,-750);
      }
      while(Motor_Pos32 > 200000 && Motor_Pos32 <= 400000){
        //sendString();
    	ReadMotorPosition32(1);
        Turn_const_speed(1,-250);
      }
      Turn_const_speed(1,0);
      absMoveSetup();
      ReadMotorPosition32(1);
      move_rel32(1,-Motor_Pos32);
      return 1;
    }
    else if(Motor_Pos32 < -400000){
      while(Motor_Pos32 < -400000){
        //sendString();
    	ReadMotorPosition32(1);
        Turn_const_speed(1,750);
      }
      while(Motor_Pos32 < -200000 && Motor_Pos32 >= -400000){
        //sendString();
    	ReadMotorPosition32(1);
        Turn_const_speed(1,250);
      }
      Turn_const_speed(1,0);
      absMoveSetup();
      ReadMotorPosition32(1);
      move_rel32(1,-Motor_Pos32);
      return 1;
    }
    else{
      Turn_const_speed(1,0);
      absMoveSetup();
      ReadMotorPosition32(1);
      move_rel32(1,-Motor_Pos32);
      return 1;
    }


  }

}
//////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////DATA READING & DISPLAY FUNCTIONS/////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////

/* Function Name: sendString
 * Author: Aidan Drescher
 * Date: 2024-03-19
 * Purpose: Sends motor position and speed to the screen
 * */
void sendString(){

  ReadMotorPosition32(1);
  classifyReadString(Motor_Pos32,'p',outputString);
  timeDelay(25);
  HAL_UART_Transmit(&huart2, (uint8_t*)outputString, strlen(outputString), HAL_MAX_DELAY);

  ReadMotorSpeed32(1);
  classifyReadString(Motor_Speed32,'s',outputString);
  timeDelay(25);
  HAL_UART_Transmit(&huart2, (uint8_t*)outputString, strlen(outputString), HAL_MAX_DELAY);

}

/* Function Name: classifyReadString
 * Author: Aidan Drescher
 * Date: 2024-04-10
 * Purpose: Decodes data strings sent from drive
 * */
void classifyReadString(long value, char charToAdd, char* result){

  char buffer[25];

  ltoa(value,buffer,10);

  //Serial.println("CLASSIFYING STRING");

  strcpy(result, buffer);

  int len = strlen(result);

  result[len] = charToAdd;
  result[len + 1] = '\0'; // Null-terminate the string

  //Serial.println("STRING CLASSIFIED");

}

/* Function Name: ltoa
 * Author: Aidan Drescher
 * Date: 2024-04-11
 * Purpose: Acts as the stdlib.h ltoa function as STM32CubeIDE does not support the native
 * Converts long interger value to string for proper data type classification.
 * */
char* ltoa(long value, char* result, int base) {

	int i = 0;
	int isNegative = 0;
	// Check for invalid base
    if (base < 2 || base > 36) {
        *result = '\0';
        return result;
    }
    // Handle negative numbers

    if (value < 0) {
        isNegative = 1;
        value = -value;
    }
    // Convert the number to string in reverse order
    do {
        int digit = value % base;
        result[i++] = (digit < 10) ? digit + '0' : digit + 'A' - 10;
        value /= base;
    } while (value > 0);

    // Add negative sign if necessary
    if (isNegative) {
        result[i++] = '-';
    }
    // Terminate the string
    result[i] = '\0';
    // Reverse the string
    int len = i;
    for (int j = 0; j < len / 2; j++) {
        char temp = result[j];
        result[j] = result[len - j - 1];
        result[len - j - 1] = temp;
    }

    return result;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////TIMER DEPENDANT FUNCTIONS////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////

/* Function Name: timeDelay
 * Author: Aidan Drescher
 * Date: 2024-02-21
 * Purpose: Uses Timer 3 to generate a delay so interrupts remain free
 * */
void timeDelay(int delay){

	__HAL_TIM_SET_COUNTER(&htim3,0);
	__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, delay);
	HAL_TIM_OC_Start_IT(&htim3, TIM_CHANNEL_1);
	while(!(delayDone));
	delayDone = 0;
	HAL_TIM_OC_Stop_IT(&htim3, TIM_CHANNEL_1);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////DYN DRIVE FUNCTIONS (DONT CHANGE)////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////

/* Function Name: Drive_Reset_RS232
 * Author: Aidan Drescher
 * Date: 2024-05-17
 * Purpose: Prepares a relative move packet to send to DMM drive
 * */
void Drive_Reset_RS232(){
	timeDelay(500);
	Global_Func = (char)General_Read;
	Send_Package(1,Is_DriveReset);
}

void Drive_Enable_RS232(){
	timeDelay(500);
	Global_Func = (char)General_Read;
	Send_Package(1,Is_DriveEnable);
}

void Drive_Disable_RS232(){
	timeDelay(500);
	Global_Func = (char)General_Read;
	Send_Package(1,Is_DriveDisable);
}
/* Function Name: move_rel32
 * Author: Tianyu Li
 * Date: 2019-02-21
 * Purpose: Prepares a relative move packet to send to DMM drive
 * */
void move_rel32(char ID, long pos)
{
  char Axis_Num = ID;
  Global_Func = (char)Go_Relative_Pos;
  Send_Package(Axis_Num, pos);
}

/* Function Name: ReadMotorTorqueCurrent
 * Author: Tianyu Li
 * Date: 2019-02-21
 * Purpose: Executes a read from the DMM drive to obtain motor torque
 * */
void ReadMotorTorqueCurrent(char ID)
{
  Global_Func = General_Read;
  Send_Package(ID , Is_TrqCurrent);
  MotorTorqueCurrentReady_Flag = 0xff;
  while(MotorTorqueCurrentReady_Flag != 0x00)
  {
    ReadPackage();
  }
}

/* Function Name: ReadMotorPosition32
 * Author: Tianyu Li
 * Date: 2019-02-21
 * Purpose: Executes a read from the DMM drive to obtain motor position in encoder pulses
 * */
void ReadMotorPosition32(char ID)
{
  Global_Func = (char)General_Read;
  Send_Package(ID , Is_AbsPos32);
  MotorPosition32Ready_Flag = 0xff;
  while(MotorPosition32Ready_Flag != 0x00)
  {
    ReadPackage();
  }
}

/* Function Name: ReadMotorSpeed32
 * Author: Aidan Drescher
 * Date: 2024-04-10
 * Purpose: Executes a read from the DMM drive to obtain motor speed in RPM
 * */
void ReadMotorSpeed32(char ID)
{
  Global_Func = (char)General_Read;
  Send_Package(ID, Is_MotorSpeed);
  MotorSpeed32Ready_Flag = 0xff;
  while(MotorSpeed32Ready_Flag != 0x00)
  {
    ReadPackage();
  }
}
/* Function Name: ReadMotorTorqueCurrent
 * Author: Tianyu Li
 * Date: 2019-02-21
 * Purpose: Prepares an absolute move packet to send to DMM drive
 * */
void move_abs32(char MotorID, long Pos32)
{
  char Axis_Num = MotorID;
  Global_Func = (char)Go_Absolute_Pos;
  Send_Package(Axis_Num, Pos32);
}

/* Function Name: Turn_const_speed
 * Author: Tianyu Li
 * Date: 2019-02-21
 * Purpose: Prepares and sends a data packet to execute a constant speed command
 * */
void Turn_const_speed(char ID, long spd)
{
      char Axis_Num = ID;
      Global_Func = 0x0a;
      Send_Package(Axis_Num, spd);
}


/* Function Name: classifyReadString
 * Author: Aidan Drescher
 * Date: 2024-04-11
 * Purpose: Reads data from drive.
 * */
void ReadPackage(void) {

  signed int c, cif;

  while (__HAL_UART_GET_FLAG(&huart3, UART_FLAG_RXNE)) {
    HAL_UART_Receive(&huart3, &c, 1, HAL_MAX_DELAY); // Receive one byte from UART
    InputBuffer[InBfTopPointer] = c; // Load InputBuffer with received packets
    InBfTopPointer++;
  }

  while (InBfBtmPointer != InBfTopPointer) {
    c = InputBuffer[InBfBtmPointer];
    InBfBtmPointer++;
    cif = c & 0x80;
    if (cif == 0) {
      Read_Num = 0;
      Read_Package_Length = 0;
    }
    if (cif == 0 || Read_Num > 0) {
      Read_Package_Buffer[Read_Num] = c;
      Read_Num++;
      if (Read_Num == 2) {
        cif = c >> 5;
        cif = cif & 0x03;
        Read_Package_Length = 4 + cif;
        c = 0;
      }
      if (Read_Num == Read_Package_Length) {
        Get_Function(); // Assuming Get_Function() is defined elsewhere
        Read_Num = 0;
        Read_Package_Length = 0;
      }
    }
  }
}

/* Function Name: Get_Function
 * Author: Tianyu Li
 * Date: 2019-02-21
 * Purpose: Decodes the desired function code and toggles related flag. Initiates data processing
 * */
void Get_Function(void) {
  char ID, ReceivedFunction_Code, CRC_Check;
  long Temp32;
  ID = Read_Package_Buffer[0] & 0x7f;
  ReceivedFunction_Code = Read_Package_Buffer[1] & 0x1f;
  CRC_Check = 0;

  for (int i = 0; i < Read_Package_Length - 1; i++) {
    CRC_Check += Read_Package_Buffer[i];
  }

  CRC_Check ^= Read_Package_Buffer[Read_Package_Length - 1];
  CRC_Check &= 0x7f;
  if (CRC_Check != 0) {
  }
  else {
    switch (ReceivedFunction_Code)
    {
      case  Is_AbsPos32:
        Motor_Pos32 = Cal_SignValue(Read_Package_Buffer);
        MotorPosition32Ready_Flag = 0x00;
        break;
      case  Is_MotorSpeed:
        Motor_Speed32 = Cal_SignValue(Read_Package_Buffer);
        MotorSpeed32Ready_Flag = 0x00;
        break;
      case  Is_TrqCurrent:
	      MotorTorqueCurrent = Cal_SignValue(Read_Package_Buffer);
	    break;
      case  Is_Status:
        Driver_Status = (char)Cal_SignValue(Read_Package_Buffer);
        // Driver_Status=drive status byte data
        break;
      case  Is_Config:
        Temp32 = Cal_Value(Read_Package_Buffer);
        //Driver_Config = drive configuration setting
        break;
      case  Is_MainGain:
        Driver_MainGain = (char)Cal_SignValue(Read_Package_Buffer);
        Driver_MainGain = Driver_MainGain & 0x7f;
        break;
      case  Is_SpeedGain:
        Driver_SpeedGain = (char)Cal_SignValue(Read_Package_Buffer);
        Driver_SpeedGain = Driver_SpeedGain & 0x7f;
        break;
      case  Is_IntGain:
        Driver_IntGain = (char)Cal_SignValue(Read_Package_Buffer);
        Driver_IntGain = Driver_IntGain & 0x7f;
        break;
      case  Is_TrqCons:
        Driver_TrqCons = (char)Cal_SignValue(Read_Package_Buffer);
        Driver_TrqCons = Driver_TrqCons & 0x7f;
        break;
      case  Is_HighSpeed:
        Driver_HighSpeed = (char)Cal_SignValue(Read_Package_Buffer);
        Driver_HighSpeed = Driver_HighSpeed & 0x7f;
        break;
      case  Is_HighAccel:
        Driver_HighAccel = (char)Cal_SignValue(Read_Package_Buffer);
        Driver_HighAccel = Driver_HighAccel & 0x7f;
        break;
      case  Is_Driver_ID:
        Driver_ReadID = ID;
        break;
      case  Is_Pos_OnRange:
        Driver_OnRange = (char)Cal_SignValue(Read_Package_Buffer);
        Driver_OnRange = Driver_OnRange & 0x7f;
        break;
    }
  }
}
/* Function Name: Cal_SignValue
 * Author: Aidan Drescher
 * Date: 2024-04-17
 * Purpose: Interprets the correct mathematical sign (pos/neg) from the 2^18 value
 * (splits into -2^17 ~ 2^17 - 1)
 * */
int32_t Cal_SignValue(unsigned char* One_Package) {
    char Package_Length, i;
    int32_t Lcmd;

    // Determine package length based on the second byte
    Package_Length = 4 + ((One_Package[1] >> 5) & 0x03);

    // Initialize the command value
    Lcmd = (One_Package[2] & 0x7F); // Mask out the sign bit

    // Extract the sign bit from the first byte
    int sign_bit = (One_Package[2] & 0x40) ? 1 : 0;

    // Sign extension if necessary
    if (sign_bit) {
        Lcmd |= 0xFFFFFF80; // Sign extend to 32 bits
    }

    // Process the remaining bytes
    for (i = 3; i < Package_Length - 1; i++) {
        Lcmd = (Lcmd << 7) | (One_Package[i] & 0x7F);
    }

    return Lcmd; // Lcmd: -2^17 ~ 2^17 - 1
}

/* Function Name: Cal_Value
 * Author: Tianyu Li
 * Date: 2019-02-21
 * Purpose:
 * */
long Cal_Value(unsigned char* One_Package)
{
  char Package_Length,OneChar,i;
  long Lcmd;
  OneChar = One_Package[1];
  OneChar = OneChar>>5;
  OneChar = OneChar&0x03;
  Package_Length = 4 + OneChar;

  OneChar = One_Package[2];   /*First byte 0x7f, bit 6 reprents sign      */
  OneChar &= 0x7f;
  Lcmd = (long)OneChar;     /*Sign extended to 32bits           */
  for(i=3;i<Package_Length-1;i++)
  {
    OneChar = One_Package[i];
    OneChar &= 0x7f;
    Lcmd = Lcmd<<7;
    Lcmd += OneChar;
  }
  return(Lcmd);         /*Lcmd : -2^27 ~ 2^27 - 1           */
}

/* Function Name: Send_Package
 * Author: Tianyu Li
 * Date: 2019-02-21
 * Purpose: Prepares and sends a data packet
 * */
void Send_Package(char ID , long Displacement) {
  unsigned char B[8], Package_Length, Function_Code;
  long TempLong;
  B[1] = B[2] = B[3] = B[4] = B[5] = (unsigned char)0x80;
  B[0] = ID & 0x7f;
  Function_Code = Global_Func & 0x1f;
  TempLong = Displacement & 0x0fffffff; //Max 28bits
  B[5] += (unsigned char)TempLong & 0x0000007f;
  TempLong = TempLong >> 7;
  B[4] += (unsigned char)TempLong & 0x0000007f;
  TempLong = TempLong >> 7;
  B[3] += (unsigned char)TempLong & 0x0000007f;
  TempLong = TempLong >> 7;
  B[2] += (unsigned char)TempLong & 0x0000007f;
  Package_Length = 7;
  TempLong = Displacement;
  TempLong = TempLong >> 20;
  if (( TempLong == 0x00000000) || ( TempLong == 0xffffffff)) { //Three byte data
    B[2] = B[3];
    B[3] = B[4];
    B[4] = B[5];
    Package_Length = 6;
  }
  TempLong = Displacement;
  TempLong = TempLong >> 13;
  if (( TempLong == 0x00000000) || ( TempLong == 0xffffffff)) { //Two byte data
    B[2] = B[3];
    B[3] = B[4];
    Package_Length = 5;
  }
  TempLong = Displacement;
  TempLong = TempLong >> 6;
  if (( TempLong == 0x00000000) || ( TempLong == 0xffffffff)) { //One byte data
    B[2] = B[3];
    Package_Length = 4;
  }
  B[1] += (Package_Length - 4) * 32 + Function_Code;
  Make_CRC_Send(Package_Length, B);
}

/* Function Name: Make_CRC_Send
 * Author: Tianyu Li
 * Date: 2019-02-21
 * Purpose: Checks packet and transmits
 * */
void Make_CRC_Send(unsigned char Plength, unsigned char* B) {
  unsigned char Error_Check = 0;
  char RS232_HardwareShiftRegister;

  for (int i = 0; i < Plength - 1; i++) {
    OutputBuffer[OutBfTopPointer] = B[i];
    OutBfTopPointer++;
    Error_Check += B[i];
  }
  Error_Check = Error_Check | 0x80;
  OutputBuffer[OutBfTopPointer] = Error_Check;
  OutBfTopPointer++;
  while (OutBfBtmPointer != OutBfTopPointer) {
    RS232_HardwareShiftRegister = OutputBuffer[OutBfBtmPointer];
    //Serial.print("RS232_HardwareShiftRegister: ");
    //Serial.println(RS232_HardwareShiftRegister, DEC);
    //use &huart3 for production
    HAL_UART_Transmit(&huart3, &RS232_HardwareShiftRegister, 1, HAL_MAX_DELAY);
    OutBfBtmPointer++; // Change to next byte in OutputBuffer to send
  }
}


///////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////STM FUNCTIONS (CAN CHANGE)////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL6;
  RCC_OscInitStruct.PLL.PREDIV = RCC_PREDIV_DIV1;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 48000;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 65535;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_OC_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_TIMING;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_OC_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */
  HAL_TIM_MspPostInit(&htim3);

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = UART2_BAUD;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief USART3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART3_UART_Init(void)
{

  /* USER CODE BEGIN USART3_Init 0 */

  /* USER CODE END USART3_Init 0 */

  /* USER CODE BEGIN USART3_Init 1 */

  /* USER CODE END USART3_Init 1 */
  huart3.Instance = USART3;
  huart3.Init.BaudRate = UART3_BAUD;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  huart3.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart3.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART3_Init 2 */

  /* USER CODE END USART3_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
